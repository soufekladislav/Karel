# Čisté nasazení — důležité

Tento ZIP je **kompletní aplikační kód**, nikoliv delta update. **Neobsahuje provozní data.**

1. Vytvoř kompletní zálohu stávající aplikace i databáze. Doporučeno nasadit nejprve na staging.
2. Zachovej původní `.env`, `.venv` (pokud máš) a celý `storage/` včetně `storage/uploads/`, `storage/workspaces/`, `storage/outputs/`, `storage/brain.json` a případného `storage/karel2.db`.
3. Pokud se databáze používá externě (MariaDB), zachovej ji samostatně a zkontroluj `DATABASE_URL` v `.env`.
4. Zastav nebo přepni provoz na údržbu, aby při kopírování nevznikly zápisy mezi starou a novou verzí.
5. Rozbal ZIP do **nového čistého adresáře**, připoj zachovanou `.env` a provozní `storage/` (ideálně přemístěním nebo mountem/symlinkem podle hostingu). NEMAŽ starou instalaci před ověřením.
6. Instaluj závislosti dle `requirements.txt` do správného virtuálního prostředí. Zachovej nastavení aplikace v cPanel/Passenger, cestu k Python prostředí a restartovací mechanismus.
7. Restartuj Passenger a otestuj přihlášení, projekty, chat, historii, soubory, Fresh Key, superadmin a práva účtů. Starou instalaci smaž až po ověření a další záloze.

**Pozor:** ponechat pouze `.env` nestačí. Pokud je používána SQLite, databáze se nachází v `storage/karel2.db`; aplikace při jejím chybění vytvoří prázdnou. U MariaDB musí být zachována původní databáze.

Žádné produkční tabulky ani uživatelská data nejsou tímto balíčkem mazána. Není přiložen migrační SQL skript, protože tato UX verze nemění schéma databáze.
