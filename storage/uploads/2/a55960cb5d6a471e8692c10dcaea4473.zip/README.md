# Karel — Clean Workspace 2.0.0-alpha.23

Kompletní čistý zdrojový balíček FastAPI aplikace; nejde o pouze rozdílový patch. Uživatelská data, `.env`, `storage/` a databáze NEJSOU jeho součástí.

- Spuštění a Passenger: `run.py`, `passenger_wsgi.py`, `.htaccess`
- Aplikace: `app/`
- Konfigurace: `.env` z dosavadní instalace, `.env.example` pouze vzor
- Před nasazením prostudovat `DEPLOY-CLEAN.md`
- Funkční změny: `RELEASE-NOTES.md`
