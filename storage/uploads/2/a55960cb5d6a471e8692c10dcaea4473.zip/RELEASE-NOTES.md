# Karel 2.0.0-alpha.23 — UX Cleanup

## Implementováno
- Horní lišta odstraněna, levá navigace sjednocena ve stylu Bobana.
- Branding Karla vlevo (stávající veřejný obrázek); přepínač přístupných projektů napojen na databázi a oprávnění uživatele.
- Zjednodušené hlavní menu: chat, přehled, zadání a dokumentace, úkoly. Ostatní oblasti pod vývojovým rozbalovacím menu.
- Výrazná tlačítka Nový chat a rozbalovací Historie chatů (aktivní + archivované, stávající serverové operace).
- Zvětšená typografie textu chatu a kompaktnější kontextový panel.
- Zachována existující projektová mapa a její editor v přehledu, dokumentace, soubory, knihovna, Fresh Key a administrace.

## Ve vývoji (nezaměňovat za hotové funkce)
- Analýza nahraného ZIP na komponenty.
- Release workflow, automatické testování, sdílený projektový kontext do ChatGPT.
- Fresh Core konektor mimo existující integrační možnosti.

## Kontroly
- Python compileall, import FastAPI a kontrola Jinja šablon.
- Lokální integrační průchod: přihlášení a zobrazení chatu, přehledu, dokumentace, úkolů, release a nastavení (HTTP 200) na testovací SQLite.
- Neproběhl prohlížečový vizuální test ani provozní test na Exon.io.

## Poznámka
- Při čištění uchovat původní .env, storage, databázi a závislosti/Python prostředí. Distribuční ZIP neobsahuje uživatelská data ani testovací databázi.
